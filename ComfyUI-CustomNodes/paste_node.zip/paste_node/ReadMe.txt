This is the basic ComfyUI LOAD IMAGE node,
but i added a Paste Image button,
which i feel has been needed for a long time.
Everything else is the same.

Coded with Google Gemini
https://gemini.google.com/app