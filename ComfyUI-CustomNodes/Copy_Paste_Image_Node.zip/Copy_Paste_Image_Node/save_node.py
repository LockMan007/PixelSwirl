import os
from nodes import SaveImage

class EnhancedSaveImage(SaveImage):
    def __init__(self):
        super().__init__()

    @classmethod
    def INPUT_TYPES(s):
        # Your fixed default prefix with all % symbols
        default_prefix = "%date:yyyy%/%date:yyyy-MM-dd%/ComfyUI_%date:yyyy-MM-dd-hhmmss%"
        return {"required": 
                    {"images": ("IMAGE", ),
                     "filename_prefix": ("STRING", {"default": default_prefix})},
                "hidden": {"prompt": "PROMPT", "extra_pnginfo": "EXTRA_PNGINFO"},
                }

    RETURN_TYPES = ()
    FUNCTION = "save_images"
    OUTPUT_NODE = True
    CATEGORY = "image"