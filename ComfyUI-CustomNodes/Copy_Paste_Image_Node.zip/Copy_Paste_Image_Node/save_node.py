import os
from nodes import SaveImage
import folder_paths

class EnhancedSaveImage(SaveImage):
    def __init__(self):
        super().__init__()

    @classmethod
    def INPUT_TYPES(s):
        # Your specific prefix
        default_prefix = "%date:yyyy%/%date:yyyy-MM-dd%/ComfyUI_%date:yyyy-MM-dd-hhmmss%"
        return {"required": 
                    {"images": ("IMAGE", ),
                     "filename_prefix": ("STRING", {"default": default_prefix})},
                "hidden": {"prompt": "PROMPT", "extra_pnginfo": "EXTRA_PNGINFO"},
                }

    RETURN_TYPES = ()
    FUNCTION = "save_enhanced_images" # Renamed to avoid conflicts
    OUTPUT_NODE = True
    CATEGORY = "image"

    def save_enhanced_images(self, images, filename_prefix, prompt=None, extra_pnginfo=None):
        # This is the "Magic" line that converts %date% into real numbers
        full_output_folder, filename, counter, subfolder, filename_prefix = \
            folder_paths.get_save_image_path(filename_prefix, folder_paths.get_output_directory(), images[0].shape[1], images[0].shape[0])
        
        # Now we call the original save_images logic with the parsed path
        return self.save_images(images, filename_prefix, prompt, extra_pnginfo)